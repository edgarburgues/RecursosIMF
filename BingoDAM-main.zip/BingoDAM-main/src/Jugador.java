import java.util.ArrayList;

public class Jugador {

	// atributos

	private ArrayList<Carton> cartones;
	private int dinero;
	private String nombre;
	private int numeroCartones;

	// constructor

	public Jugador(int dinero, String nombre, int numeroCartones) {
		super();
		this.dinero = dinero;
		this.nombre = nombre;
		this.numeroCartones = numeroCartones;
	}

	// metodos

	public ArrayList<Carton> getCartones() {
		return cartones;
	}

	public void setCartones(ArrayList<Carton> cartones) {
		this.cartones = cartones;
	}

	public int getDinero() {
		return dinero;
	}

	public void setDinero(int dinero) {
		this.dinero = dinero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumeroCartones() {
		return numeroCartones;
	}

	public void setNumeroCartones(int numeroCartones) {
		this.numeroCartones = numeroCartones;
	}

	public void addCartones(int numeroCartones) {
		cartones = new ArrayList<Carton>();
		for (int i = 0; i < numeroCartones; i++) {
			cartones.add(new Carton());
			cartones.get(i).crearCarton();
		}
	}

	

}