import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Bolas bolas = new Bolas();
		Jugadores jugadores = new Jugadores();
		String nombreGanador = "";
		String nombreLinea = "";
		String nombre;
		int precioCarton= 2;
		int numeroJugadores = 0;
		int dinero = 0;
		int cartones = 0;
		boolean linea = false;
		boolean bingo = false;

		System.out.println("---------------");
		System.out.println("-----Bingo-----");
		System.out.println("---------------");

		do {
			System.out.print("�Cu�ntas personas vais a jugar?: ");
			try {
				numeroJugadores = (Integer.parseInt(scanner.nextLine()));
			} catch (Exception e) {
				System.out.println("No has introducido un n�mero v�lido");
			}
		} while (numeroJugadores <= 0);

		for (int i = 0; i < numeroJugadores; i++) {
			System.out.print("Introduce el nombre: ");
			nombre = scanner.nextLine();

			do {
				System.out.print("Cu�nto dinero tienes?: ");
				try {
					dinero = (Integer.parseInt(scanner.nextLine()));
				} catch (Exception e) {
					System.out.println("No has introducido un n�mero v�lido");
				}
			} while (dinero <= 0);

			do {
				System.out.print("Cu�ntos cartones quieres?: ");
				try {
					cartones = (Integer.parseInt(scanner.nextLine()));
				} catch (Exception e) {
					System.out.println("No has introducido un n�mero v�lido");
				}
			} while (cartones < 0 && jugadores.getListaJugadores().get(i).getDinero() >= cartones*precioCarton);

			jugadores.addJugador(nombre, dinero, cartones);
			jugadores.getListaJugadores().get(i).addCartones(cartones);

			for (int j = 0; j < jugadores.getListaJugadores().get(i).getCartones().size(); j++) {
				jugadores.getListaJugadores().get(i).getCartones().get(j).mostrarCarton();
				System.out.println("---------------------------------------------");
			}
		}

		do {
			System.out.println("Sale el n�mero: " + bolas.sacarBola());
			for (int i = 0; i < numeroJugadores; i++) {
				System.out.println("Tachando n�meros en el cart�n");
				for (int j = 0; j < jugadores.getListaJugadores().get(i).getCartones().size(); j++) {
					jugadores.getListaJugadores().get(i).getCartones().get(j).comprobarNumero(bolas.sacarBola());
				}
				if (!linea) {
					System.out.println("Comprobando si alguien ha hecho linea");
					for (int j = 0; j < jugadores.getListaJugadores().get(i).getCartones().size(); j++) {
						if (jugadores.getListaJugadores().get(i).getCartones().get(j).comprobarLinea()) {
							linea = true;
							nombreLinea = jugadores.getListaJugadores().get(i).getNombre();
						}
					}
				}

				if (!bingo) {
					System.out.println("Comprobando si alguien tiene BINGO");
					for (int j = 0; j < jugadores.getListaJugadores().get(i).getCartones().size(); j++) {
						if (jugadores.getListaJugadores().get(i).getCartones().get(j).comprobarBingo()) {
							bingo = true;
							nombreGanador = jugadores.getListaJugadores().get(i).getNombre();
						}
					}
				}

				for (int j = 0; j < jugadores.getListaJugadores().get(i).getCartones().size(); j++) {
					System.out.println(jugadores.getListaJugadores().get(i).getNombre());
					jugadores.getListaJugadores().get(i).getCartones().get(j).mostrarCarton();
					System.out.println("---------------------------------------------");
				}

			}
			bolas.borrarBola();
		} while (!bingo);

		System.out.println("Ha hecho linea " + nombreLinea);
		System.out.println("Ha ganado " + nombreGanador);

		scanner.close();

	}

}
