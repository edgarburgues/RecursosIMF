import java.util.ArrayList;

public class Jugadores {

	// atributos

	private ArrayList<Jugador> listaJugadores;
	private int dinero;
	private String nombre;
	private Jugador jugador;
	private int numeroCartones;

	// constructor

	public Jugadores() {
		listaJugadores = new ArrayList<Jugador>();
	}

	public ArrayList<Jugador> getListaJugadores() {
		return listaJugadores;
	}

	public void setListaJugadores(ArrayList<Jugador> listaJugadores) {
		this.listaJugadores = listaJugadores;
	}

	public int getDinero() {
		return dinero;
	}

	public void setDinero(int dinero) {
		this.dinero = dinero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Jugador getJugador() {
		return jugador;
	}

	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}

	public int getNumeroCartones() {
		return numeroCartones;
	}

	public void setNumeroCartones(int numeroCartones) {
		this.numeroCartones = numeroCartones;
	}

	// metodos

	public void addJugador(String nombre, int dinero, int numeroCartones) {
		listaJugadores.add(new Jugador(dinero, nombre, numeroCartones));

	}

	public void listar() {
		for (int i = 0; i < listaJugadores.size(); i++) {
			System.out.println("nombre: " + listaJugadores.get(i).getNombre() + " Dinero: "
					+ listaJugadores.get(i).getDinero() + " Cartones: " + listaJugadores.get(i).getNumeroCartones());
		}

	}

}