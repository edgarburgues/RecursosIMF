import java.util.ArrayList;
import java.util.Collections;

/**
 * Genera 99 bolas diferentes y permite sacar una de forma aleatoria.
 * 
 * @author Raquel Garcia San Justo
 * @version 2.0
 */
public class Bolas {
	

	private ArrayList<Integer> bolasLista = new ArrayList<Integer>();

	public Bolas() {
		for (int i = 1; i <= 99; i++) {
			bolasLista.add(i);
		}
		Collections.shuffle(bolasLista);
	}
	/**
	 * Saca una bola.
	 * @author Raquel Garc�a
	 * @return int
	 */

	public int sacarBola() {
		return bolasLista.get(0);
	}
	/**
	 * Borra la primera posici�n del ArrayList BolasLista
	 * @author Raquel Garc�a
	 */
	
	public void borrarBola() {
		bolasLista.remove(0);
	}

	public ArrayList<Integer> getBolasLista() {
		return bolasLista;
	}

	public void setBolasLista(ArrayList<Integer> bolasLista) {
		this.bolasLista = bolasLista;
	}

	@Override
	public String toString() {
		return "Bolas [bolasLista=" + bolasLista + "]";
	}

}