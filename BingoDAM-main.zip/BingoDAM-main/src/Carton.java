import java.util.ArrayList;
import java.util.Collections;

public class Carton {
	private int[][] carton = new int[3][10];
	private ArrayList<Integer> columnaCarton = new ArrayList<Integer>();
	private int contadorColumnaCarton = 1;
	private int contadorCartones = 0;
	private int suma = 0;

	// Constructor, get, set

	public Carton() {

	}

	public int[][] getCarton() {
		return carton;
	}

	public void setCarton(int[][] carton) {
		this.carton = carton;
	}

	public ArrayList<Integer> getColumnaCarton() {
		return columnaCarton;
	}

	public void setColumnaCarton(ArrayList<Integer> columnaCarton) {
		this.columnaCarton = columnaCarton;
	}

	public int getContadorColumnaCarton() {
		return contadorColumnaCarton;
	}

	public void setContadorColumnaCarton(int contadorColumnaCarton) {
		this.contadorColumnaCarton = contadorColumnaCarton;
	}

	public int getContadorCartones() {
		return contadorCartones;
	}

	public void setContadorCartones(int contadorCartones) {
		this.contadorCartones = contadorCartones;
	}

	// M�todos

	public void crearCarton() {
		for (int i = 1; i <= 10; i++) {
			for (int j = contadorColumnaCarton; j < contadorColumnaCarton + 10; j++) {
				columnaCarton.add(j);
			}
			Collections.shuffle(columnaCarton);

			carton[0][i - 1] = columnaCarton.get(0);
			carton[1][i - 1] = columnaCarton.get(1);
			carton[2][i - 1] = columnaCarton.get(2);

			columnaCarton.clear();
			contadorColumnaCarton = i * 10;
		}

	}

	public void mostrarCarton() {

		for (int i = 0; i < carton.length; i++) {
			for (int j = 0; j < carton[i].length; j++) {

				System.out.print(" " + carton[i][j] + " ");
			}
			System.out.println("\n");
		}
	}

	public boolean comprobarLinea() {
		boolean linea = false;
		for (int i = 0; i < carton.length; i++) {
			suma = 0;
			for (int j = 0; j < carton[i].length; j++) {
				suma += carton[i][j];
			}
			if (suma == 0) {
				linea = true;
			}
		}
		return linea;
	}

	public boolean comprobarBingo() {
		boolean bingo = false;
		suma = 0;
		for (int i = 0; i < carton.length; i++) {
			for (int j = 0; j < carton[i].length; j++) {
				suma += carton[i][j];
			}

		}
		if (suma == 0) {
			bingo = true;
		}
		return bingo;
	}

	public void comprobarNumero(int bola) {
		for (int i = 0; i < carton.length; i++) {
			for (int j = 0; j < carton[i].length; j++) {
				if (carton[i][j] == bola) {
					carton[i][j] = 0;
				}
			}
		}

	}
}
