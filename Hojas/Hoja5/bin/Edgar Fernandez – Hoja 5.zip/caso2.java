import java.util.Arrays;
import java.util.Scanner;

public class caso2 {

	public static void main(String[] args) {
		// Pregunta al usuario por dos arrays de caracteres y mézclalos.
		// Por ejemplo: “ABCD” y “1234”
		// EL resultado será “A1B2C3D4”
		// Se valora que el usuario seleccione el tamaño de los arrays.

		String palabra1;
		String palabra2;
		byte longitudPeq;

		Scanner scanner = new Scanner(System.in);

		System.out.print("Introduce una palabra: ");
		palabra1 = scanner.nextLine();
		System.out.print("Introduce otra palabra: ");
		palabra2 = scanner.nextLine();

		char[] cadena1 = palabra1.toCharArray();
		char[] cadena2 = palabra2.toCharArray();

		if (cadena1.length > cadena2.length) {
			longitudPeq = (byte) (cadena2.length);
		} else {
			longitudPeq = (byte) (cadena1.length);
		}

		for (int i = 0; i < longitudPeq; i++) {
			System.out.print(cadena1[i]);
			System.out.print(cadena2[i]);
		}

		if (cadena1.length > cadena2.length) {
			for (int i = longitudPeq; i < cadena1.length; i++) {
				System.out.print(cadena1[i]);
			}
		} else if (cadena1.length < cadena2.length) {
			for (int i = longitudPeq; i < cadena2.length; i++) {
				System.out.print(cadena2[i]);
			}
		}

		scanner.close();
	}
}
