package Controlador;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Ficheros {

	public Ficheros() {
		super();

	}

	public static String leerEnFichero(String nombreTxt) {
		String cadena = "Ha ocurrido un error";
		FileReader fichero = null;
		BufferedReader lector = null;
		try {
			fichero = new FileReader("data/" + nombreTxt + ".txt");
			lector = new BufferedReader(fichero);

			cadena = lector.readLine();

		} catch (FileNotFoundException e) {
			System.out.println("No se encuentra el fichero");
		} catch (IOException e) {
			System.out.println("Hay un problema de lectura");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (lector != null) {
					lector.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cadena;
	}

	public static void EscribirEnFichero(String path) {
		FileWriter fichero = null;
		try {
			fichero = new FileWriter(path, true);

		} catch (FileNotFoundException e) {
			System.out.println("No se encuentra el fichero");
		} catch (IOException e) {
			System.out.println("Hay un problema de lectura");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (fichero != null) {
					fichero.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
