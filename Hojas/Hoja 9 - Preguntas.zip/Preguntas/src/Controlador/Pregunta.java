package Controlador;

import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;

public class Pregunta {

	@FXML
	private RadioButton radio5;

	@FXML
	private TextArea areaPregunta;

	@FXML
	private RadioButton radio3;

	@FXML
	private RadioButton radio4;

	@FXML
	private RadioButton radio1;

	@FXML
	private RadioButton radio2;

	@FXML
	private ToggleGroup respuesta;

	public void initialize() {
		getPregunta();

	}

	private void getPregunta() {
		areaPregunta.setEditable(false);
		areaPregunta.clear();
		ResultSet rs = null;
		try {
			rs = Conexion.execSQL("localhost", "hoja9", "root", "",
					"SELECT * FROM `preguntas` where id=" + Controlador.listaNumeros.get(0), false);
			if (rs.next()) {
				areaPregunta.appendText(rs.getString("texto"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Controlador.listaNumeros.remove(0);
	}
}
