-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-05-2022 a las 13:03:27
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hoja9`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carlos`
--

CREATE TABLE `carlos` (
  `id` int(20) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `img_link` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `texto` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `carlos`
--

INSERT INTO `carlos` (`id`, `nombre`, `img_link`, `texto`) VALUES
(2, 'Juan Carlos', NULL, ''),
(3, 'Carlos enfermera sexy', NULL, ''),
(4, 'Carlos Minecraft', NULL, ''),
(5, 'BlablaCarlos', NULL, ''),
(6, 'Deja de toCAR LOS huevos', NULL, ''),
(7, 'Carlos DJ', NULL, ''),
(8, 'Carlos Feliz', NULL, ''),
(9, 'Carlos Triste', NULL, ''),
(10, 'Carlos Enfadado', NULL, ''),
(11, 'Carlos Cansado', NULL, ''),
(12, 'Carlos Kawaii', NULL, ''),
(13, 'Carlos 1a Evaluación', NULL, ''),
(14, 'Carlos 2a Evaluación', NULL, ''),
(15, 'Carlos Semana Caliente', NULL, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mood`
--

CREATE TABLE `mood` (
  `id` int(11) NOT NULL,
  `nombre_mood` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mood`
--

INSERT INTO `mood` (`id`, `nombre_mood`) VALUES
(1, 'enfado'),
(2, 'alegre'),
(3, 'aburrido'),
(4, 'preocupado'),
(5, 'tranquilo'),
(6, 'deprimido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id` int(20) NOT NULL,
  `texto` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `mood` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id`, `texto`, `mood`) VALUES
(1, 'Soy emocionalmente estable y difícil de alterar.', 1),
(2, 'Con frecuencia se me ocurren ideas nuevas.', NULL),
(3, 'Soy minucioso/a en el trabajo.', NULL),
(4, 'Me preocupo por todo.', NULL),
(5, 'Hago amigos con facilidad.', NULL),
(6, 'Tengo mucha imaginación.', NULL),
(7, 'Confío en los demás.', NULL),
(8, 'Completo las tareas con éxito.', NULL),
(9, 'Me enfado con facilidad.', NULL),
(10, 'Disfruto mucho en las grandes fiestas y reuniones.', NULL),
(11, 'Creo que el arte es importante.', NULL),
(12, 'A veces engaño a los demás para salirme con la mí­a.', NULL),
(13, 'No me gusta que las cosas estén desordenadas, me gusta ordenar.', NULL),
(14, 'A menudo me siento triste.', NULL),
(15, 'Me gusta hacerme cargo de la situación.', NULL),
(16, 'Experimento emociones profundas y variadas.', NULL),
(17, 'Me encanta ayudar a los demás.', NULL),
(18, 'Siempre cumplo mis promesas.', NULL),
(19, 'Me resulta difícil acercarme a los demás.', NULL),
(20, 'Siempre estoy ocupado, de aquí­ para allá.', NULL),
(21, 'Prefiero la variedad a la rutina.', NULL),
(22, 'Me encanta discutir o pelear.', NULL),
(23, 'Trabajo muy duro.', NULL),
(24, 'Hago excesos algunas veces.', NULL),
(25, 'Me encantan las sensaciones fuertes.', NULL),
(26, 'Disfruto leyendo libros y artículos interesantes.', NULL),
(27, 'Creo que soy mejor que los demás.', NULL),
(28, 'Siempre estoy preparado para lo que sea.', NULL),
(29, 'Entro en pánico con facilidad.', NULL),
(30, 'Soy una persona muy alegre.', NULL),
(31, 'Tiendo a apoyar el progreso y las reformas.', NULL),
(32, 'Me solidarizo con los indigentes.', NULL),
(33, 'Soy muy espontáneo, actúo sin pensar.', NULL),
(34, 'Siempre me temo lo peor.', NULL),
(35, 'Me siento cómodo rodeado de gente.', NULL),
(36, 'Me gusta dejar volar la imaginación.', NULL),
(37, 'Creo que la gente, en general, tiene buenas intenciones.', NULL),
(38, 'Cuando hago algo, siempre lo hago bien.', NULL),
(39, 'Me irrito con facilidad.', NULL),
(40, 'En las fiestas siempre hablo con mucha gente distinta.', NULL),
(41, 'Veo belleza en cosas que para otras personas pueden pasar inadvertidas.', NULL),
(42, 'No me importa hacer trampas para progresar.', NULL),
(43, 'A menudo olvido poner las cosas de nuevo en su sitio.', NULL),
(44, 'A veces no me gusto.', NULL),
(45, 'Intento estar al mando y liderar a los demás.', NULL),
(46, 'Soy empático, capto las emociones de los demás.', NULL),
(47, 'Me preocupo por los demás.', NULL),
(48, 'Digo la verdad.', NULL),
(49, 'Tengo miedo de llamar la atención.', NULL),
(50, 'Nunca estoy quieto, siempre estoy de aquí para allá.', NULL),
(51, 'Prefiero limitarme a las cosas que conozco.', NULL),
(52, 'Grito a la gente.', NULL),
(53, 'Hago más de lo que se espera de mí.', NULL),
(54, 'Pocas veces caigo en excesos.', NULL),
(55, 'Hago todo lo posible por buscar la aventura.', NULL),
(56, 'Evito las discusiones filosóficas.', NULL),
(57, 'Tengo un alto concepto de mí mismo.', NULL),
(58, 'Saco adelante mis planes y trabajos.', NULL),
(59, 'A menudo los acontecimientos me sobrepasan.', NULL),
(60, 'Me divierto mucho.', NULL),
(61, 'Creo que no existe el Bien o el Mal absoluto.', NULL),
(62, 'Siento compasión por aquellos que están peor que yo.', NULL),
(63, 'Tomo decisiones precipitadas.', NULL),
(64, 'Me dan miedo muchas cosas.', NULL),
(65, 'Si es posible, evito entrar en contacto con la gente.', NULL),
(66, 'Me gusta soñar despierto.', NULL),
(67, 'Creo lo que la gente dice.', NULL),
(68, 'Hago las tareas de manera metódica.', NULL),
(69, 'A menudo pierdo los estribos.', NULL),
(70, 'Prefiero estar solo.', NULL),
(71, 'No me gusta la poesía.', NULL),
(72, 'A veces me aprovecho de los demás.', NULL),
(73, 'A veces lo dejo todo muy desordenado.', NULL),
(74, 'A veces estoy deprimido/a.', NULL),
(75, 'Tomo el control de las situaciones.', NULL),
(76, 'Pocas veces reparo en mis reacciones emocionales y sentimientos.', NULL),
(77, 'Me muestro indiferente ante los sentimientos de los demás.', NULL),
(78, 'Rompo las reglas.', NULL),
(79, 'Solo me siento realmente cómodo con mis amigos', NULL),
(80, 'Hago muchas cosas en mi tiempo libre.', NULL),
(81, 'No me gustan los cambios.', NULL),
(82, 'Insulto a la gente.', NULL),
(83, 'Trabajo lo justo y necesario.', NULL),
(84, 'Resisto las tentaciones fácilmente.', NULL),
(85, 'Me gusta tomar riesgos.', NULL),
(86, 'Tengo dificultades para entender las ideas abstractas.', NULL),
(87, 'Tengo muy buena opinión de mí­ mismo.', NULL),
(88, 'Suelo perder el tiempo.', NULL),
(89, 'Siento que no soy capaz de hacer frente a las cosas.', NULL),
(90, 'Adoro la vida.', NULL),
(91, 'Creo que la ley se debe cumplir estrictamente.', NULL),
(92, 'No me interesan los problemas de los demás.', NULL),
(93, 'Suelo precipitarme.', NULL),
(94, 'Me estreso con facilidad.', NULL),
(95, 'Procuro mantener las distancias con los demás.', NULL),
(96, 'Me gusta abstraerme.', NULL),
(97, 'Desconfí­o de la gente.', NULL),
(98, 'Sé cómo hacer las cosas.', NULL),
(99, 'No me molesto con facilidad.', NULL),
(100, 'Evito las multitudes.', NULL),
(101, 'No me gusta ir a museos ni exposiciones de arte.', NULL),
(102, 'A veces soy bastante renuente y pongo trabas a los planes de otras personas.', NULL),
(103, 'Suelo dejar todas mis cosas desperdigadas.', NULL),
(104, 'Me siento a gusto conmigo mismo.', NULL),
(105, 'Espero a que los demás tomen el liderazgo.', NULL),
(106, 'No entiendo a la gente que se pone sentimental.', NULL),
(107, 'No tengo tiempo para los demás.', NULL),
(108, 'A veces rompo mis promesas.', NULL),
(109, 'No me afectan las situaciones sociales difíciles.', NULL),
(110, 'Reacciono con lentitud.', NULL),
(111, 'Simpatizo con los estilos de vida tradicionales.', NULL),
(112, 'Siempre me tomo mi revancha con los demás.', NULL),
(113, 'A veces dedico poco tiempo y esfuerzo a mi trabajo.', NULL),
(114, 'Soy capaz de controlar mis deseos.', NULL),
(115, 'Me gusta la acción y el peligro.', NULL),
(116, 'No me interesan las discusiones teÃ³ricas.', NULL),
(117, 'Me gusta hablar sobre mis cualidades.', NULL),
(118, 'Me cuesta empezar las tareas.', NULL),
(119, 'Bajo presión me mantengo en calma.', NULL),
(120, 'Siempre miro el lado bueno de la vida.', NULL),
(121, 'Creo que deberÃ­amos ser implacables con la delincuencia.', NULL),
(122, 'Intento no pensar en los necesitados.', NULL),
(123, 'Actúo sin pensar.', NULL),
(124, 'Tengo claras mis metas en la vida.', NULL),
(125, 'Confío en mi trabajo.', NULL),
(126, 'Puedo trabajar incluso cuando hay caos a mi alrededor.', NULL),
(127, 'Me esfuerzo y pongo empeÃ±o en mi trabajo.', NULL),
(128, 'Prefiero alcanzar mis objetivos que ayudar a otros a que los consigan.', NULL),
(129, 'Soy ambicioso/a.', NULL),
(130, 'Es preferible que salga adelante el trabajo a tratar de hacerlo perfecto.', NULL),
(131, 'Soy capaz de completar tareas tan bien o incluso mejor que otras personas.', NULL),
(132, 'Me gusta estar al cargo de otras personas.', NULL),
(133, 'El día no tiene suficientes horas para todo lo que hay que hacer.', NULL),
(134, 'Me impaciento por el ritmo al que se desarrollan los acontecimientos.', NULL),
(135, 'Con frecuencia me someto a plazos que son difÃ­ciles de cumplir.', NULL),
(136, 'Me describiría como una persona absolutamente competente.', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `enfado` int(11) NOT NULL,
  `alegre` int(11) NOT NULL,
  `aburrido` int(11) NOT NULL,
  `preocupado` int(11) NOT NULL,
  `tranquilo` int(11) NOT NULL,
  `deprimido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `enfado`, `alegre`, `aburrido`, `preocupado`, `tranquilo`, `deprimido`) VALUES
(1, 'testUser', 0, 0, 0, 0, 0, 0),
(18, '', 0, 0, 0, 0, 0, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carlos`
--
ALTER TABLE `carlos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mood`
--
ALTER TABLE `mood`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carlos`
--
ALTER TABLE `carlos`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `mood`
--
ALTER TABLE `mood`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
